# No Code Contributions

## Examples

PAIRING on Discord

```
| [Steve Dsouza](https://github.com/stevenovak123) | Pair programmed on Discord | 2022/10/22 | [#2060](https://github.com/EddieHubCommunity/LinkFree/pull/2060) |
```

YouTube (or blog)

```
| [Eddie Jaoude](https://github.com/eddiejaoude) | YouTube | 2022/10/22 | [Contributing Open Source](https://www.youtube.com/watch?v=8B_JWf7pG20) |
```

## Contributions

| CONTRIBUTOR | CONTRIBUTION | DATE (YYYY/MM/DD) | RESOURCE LINK (PR, Blog, Video) |
| :---------- | :----------- | :---------------- | :------------------------------ |
| [Christine Belzie](https://github.com/CBID2) | Pair programmed on Discord | 2022/10/29 | [#2060](https://github.com/EddieHubCommunity/LinkFree/pull/2060) |
| [Jaynarayan vaishnav](https://github.com/jaynarayan-vaishnav) | Pair programmed on Discord | 2022/10/31 | [#2079](https://github.com/EddieHubCommunity/LinkFree/pull/2080) |
