# 1.50.0 (2023-01-15)


### Features

* total users ([#3458](https://github.com/EddieHubCommunity/LinkFree/issues/3458)) ([8463d78](https://github.com/EddieHubCommunity/LinkFree/commit/8463d783b674c9b9d64fe6529ed220254187d5b3))



